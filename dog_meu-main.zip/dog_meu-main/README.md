# DogMeu [https://github.com/b4arbosa]
Esse é um site não oficial de uma empresa não oficial, porém com algumas informações oficiais e conteúdo de outras empresa reais.
Lembrando que tudo que foi usado é apenas para uso escolar. pls não me processem

Site criado pelo aluno Pedro Cavalcanti para a obtenção de nota da disciplina de Introdução á Web.
